import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import UserProfile from "./components/UserProfile";
import LoginPage from "./components/LoginPage"; // Create this component
import { handleCallback } from "./authService"; // Import the handleCallback function

const App = () => {
  return (
    <Router>
      <div>
        <h1>Welcome to My Casdoor App</h1>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/callback" element={<CallbackHandler />} />
        </Routes>
      </div>
    </Router>
  );
};

const CallbackHandler = () => {
  // Handle the callback from Casdoor
  handleCallback();

  return <div>Loading...</div>;
};

export default App;

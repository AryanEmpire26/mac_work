// src/authService.js

import { CasdoorSDK } from "casdoor-js-sdk";
import casdoorConfig from "./casdoorConfig";

const casdoor = new CasdoorSDK(casdoorConfig);

// Login function
export const login = async () => {
  const url = await casdoor.getLoginUrl();
  window.location.href = url; // Redirect to the login page
};

// Handle the callback from Casdoor
export const handleCallback = () => {
  const urlParams = new URLSearchParams(window.location.search);
  const code = urlParams.get("code");
  const state = urlParams.get("state");

  if (code) {
    // Exchange the code for an access token
    casdoor
      .getAccessToken(code, state)
      .then((resp) => {
        const { accessToken } = resp;
        localStorage.setItem("accessToken", accessToken);
        window.location.href = "/"; // Redirect to the main page after successful login
      })
      .catch((error) => {
        console.error("Error during token exchange:", error);
        // Handle error (e.g., show an error message to the user)
      });
  } else {
    // Handle cases where there is no code
    console.error("No code found in the URL");
  }
};

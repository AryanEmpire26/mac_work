// src/casdoorConfig.js

const casdoorConfig = {
  serverUrl: "http://localhost:8000",
  clientId: "6fd3391a66e4bb91ad37",
  appName: "application_z6dj79_aryan", // Replace with your Casdoor application name
  organizationName: "organization_qqgypk_aryan", // Replace with your Casdoor organization name
  redirectUri: "http://localhost:9000/callback", // Replace with your redirect URI
};

export default casdoorConfig;

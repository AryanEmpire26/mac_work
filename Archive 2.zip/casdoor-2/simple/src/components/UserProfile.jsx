import React, { useEffect, useState } from "react";
import {
  getUserProfileUrl,
  getMyProfileUrl,
  getUserInfo,
  logout,
} from "../authService";

const UserProfile = ({ userName, account, accessToken }) => {
  const [userInfo, setUserInfo] = useState(null);

  useEffect(() => {
    const fetchUserInfo = async () => {
      const info = await getUserInfo(accessToken);
      setUserInfo(info);
    };

    fetchUserInfo();
  }, [accessToken]);

  return (
    <div>
      <h1>User Profile</h1>
      {userInfo ? (
        <div>
          <p>Name: {userInfo.name}</p>
          <p>Email: {userInfo.email}</p>
          <p>
            Profile URL:{" "}
            <a href={getUserProfileUrl(userName, account)}>View Profile</a>
          </p>
          <p>
            My Profile URL: <a href={getMyProfileUrl(account)}>My Profile</a>
          </p>
          <button onClick={logout}>Logout</button>
        </div>
      ) : (
        <p>Loading user info...</p>
      )}
    </div>
  );
};

export default UserProfile;

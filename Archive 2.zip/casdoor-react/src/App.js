import "./App.css";

import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import HomePage from "./HomePage";
import { AuthCallback } from "./AuthCallback";

class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/callback" element={<AuthCallback />} />
        </Routes>
      </BrowserRouter>
    );
  }
}

export default App;

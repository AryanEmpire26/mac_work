import React, { useEffect, useState } from "react";
import * as Setting from "./Setting";
import LoginPage from "./LoginPage";

const HomePage = () => {
  const [account, setAccount] = useState(undefined);

  useEffect(() => {
    if (Setting.isLoggedIn()) {
      Setting.getUserinfo().then((res) => {
        setAccount(res);
      });
    }
  }, []);

  const logout = () => {
    Setting.logout();
    Setting.showMessage("logout successfully");
    Setting.goToLink("/");
  };

  if (Setting.isLoggedIn()) {
    if (account) {
      console.log(account);
      return (
        <div
          style={{ marginTop: 200, textAlign: "center", alignItems: "center" }}
        >
          <img
            width={100}
            height={100}
            src={account.picture}
            alt={account.name}
          />
          <p>{account.name}</p>
          <button onClick={Setting.goToProfilePage}>Profile</button>
          <br />
          <br />
          <button onClick={logout}>Logout</button>
        </div>
      );
    }
  }

  return (
    <div style={{ marginTop: 200 }}>
      <LoginPage />
    </div>
  );
};

export default HomePage;

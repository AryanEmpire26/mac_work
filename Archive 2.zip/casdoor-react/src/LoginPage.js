import React from "react";
import * as Setting from "./Setting";

const LoginPage = () => {
  const login = () => {
    Setting.CasdoorSDK.signin_redirect();
  };

  return (
    <div
      style={{
        textAlign: "center",
        alignItems: "center",
      }}
    >
      <button onClick={login}>Casdoor Login</button>
    </div>
  );
};

export default LoginPage;

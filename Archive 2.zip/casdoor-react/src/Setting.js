import Sdk from "casdoor-js-sdk";

const sdkConfig = {
  serverUrl: "http://localhost:8000",
  clientId: "6fd3391a66e4bb91ad37",
  appName: "application_z6dj79_aryan",
  organizationName: "organization_qqgypk_aryan",
  redirectUri: "http://localhost:9000/callback",
};

export const CasdoorSDK = new Sdk(sdkConfig);

export const isLoggedIn = () => {
  const token = getToken();
  return token !== null && token.length > 0;
};

export const setToken = (token) => {
  localStorage.setItem("accessToken", token);
};

export const getToken = () => {
  return localStorage.getItem("accessToken");
};

export const goToLink = (link) => {
  window.location.href = link;
};

export const getUserinfo = () => {
  return CasdoorSDK.getUserInfo(getToken());
};

export const goToProfilePage = () => {
  window.location.assign(CasdoorSDK.getMyProfileUrl());
};

export const logout = () => {
  localStorage.removeItem("accessToken");
};

export const showMessage = (message) => {
  alert(message);
};

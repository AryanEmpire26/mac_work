// src/components/Callback.js
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import casdoor from "../casdoor";

const Callback = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const handleCallback = async () => {
      try {
        const tokenResponse = await casdoor.handleCallback();

        if (tokenResponse && tokenResponse.access_token) {
          localStorage.setItem(
            "casdoor_access_token",
            tokenResponse.access_token
          ); // Store the token
          navigate("/dashboard"); // Redirect to dashboard after login
        } else {
          console.error("No access token returned.");
        }
      } catch (error) {
        console.error("Error handling callback:", error);
      }
    };

    handleCallback();
  }, [navigate]);

  return (
    <div>
      <h2>Logging you in...</h2>
    </div>
  );
};

export default Callback;

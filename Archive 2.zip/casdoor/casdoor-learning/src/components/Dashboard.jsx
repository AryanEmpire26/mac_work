// src/components/Dashboard.js
import React, { useState, useEffect } from "react";
import casdoor from "../casdoor";

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const accessToken = localStorage.getItem("casdoor_access_token");

        if (!accessToken) {
          throw new Error("No access token found.");
        }

        // Fetch user info using the access token
        const userInfo = await casdoor.getUserInfo(accessToken);
        setUser(userInfo);
      } catch (err) {
        console.error("Error fetching user info:", err);
        setError(err.message);
      }
    };

    fetchUserInfo();
  }, []);

  return (
    <div>
      <h2>Dashboard</h2>
      {error ? (
        <p>Error: {error}</p>
      ) : user ? (
        <div>
          <p>Welcome, {user.name}!</p>
          <p>Email: {user.email}</p>
        </div>
      ) : (
        <p>Loading user info...</p>
      )}
    </div>
  );
};

export default Dashboard;

// src/components/Login.js

import React from "react";
import casdoor from "../casdoor";

const Login = () => {
  const login = () => {
    window.location.href = casdoor.getSigninUrl();
  };

  return (
    <div>
      <h2>Login to Casdoor</h2>
      <button onClick={login}>Login with Casdoor</button>
    </div>
  );
};

export default Login;

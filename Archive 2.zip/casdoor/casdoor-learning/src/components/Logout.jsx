// src/components/Logout.js

import React from "react";
import casdoor from "../casdoor";

const Logout = () => {
  const logout = () => {
    casdoor.signout();
    localStorage.removeItem("token");
    window.location.href = "/";
  };

  return <button onClick={logout}>Logout</button>;
};

export default Logout;

"use client";
import {
  Button
} from "./chunk-6UWW4N3F.js";
import "./chunk-WXK4NJHA.js";
import "./chunk-HCGKX5ED.js";
import "./chunk-WNPTCGAH.js";
import "./chunk-5WRI5ZAA.js";
export {
  Button
};
//# sourceMappingURL=primereact_button.js.map

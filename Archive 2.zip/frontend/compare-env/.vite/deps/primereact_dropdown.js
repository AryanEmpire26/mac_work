"use client";
import {
  Dropdown
} from "./chunk-ULZGLIKO.js";
import "./chunk-WXK4NJHA.js";
import "./chunk-HCGKX5ED.js";
import "./chunk-WNPTCGAH.js";
import "./chunk-5WRI5ZAA.js";
export {
  Dropdown
};
//# sourceMappingURL=primereact_dropdown.js.map

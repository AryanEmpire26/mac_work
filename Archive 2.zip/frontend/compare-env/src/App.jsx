import DropdownMenu from "./components/DropdownMenu";
import { ApolloProviderComponent } from "./ApolloClient";

function App() {
  return (
    <ApolloProviderComponent>
      <h2>Environments comparison</h2>
      <DropdownMenu />
    </ApolloProviderComponent>
  );
}

export default App;

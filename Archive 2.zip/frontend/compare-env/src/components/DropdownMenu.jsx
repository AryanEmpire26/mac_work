import React, { useEffect, useState } from "react";
import { Dropdown } from "primereact/dropdown";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { useLazyQuery } from "@apollo/client";
import { GET_COMPARISON } from "../queries";

const DropdownMenu = () => {
  const [selectedOpt1, setSelectedOpt1] = useState(null);
  const [selectedOpt2, setSelectedOpt2] = useState(null);
  const [selectedOpt3, setSelectedOpt3] = useState(null);
  const [data, setData] = useState([]);
  const [showTable, setShowTable] = useState(false);
  const [opts1, setOpts1] = useState([]);

  const [getComparison, { loading, data: comparisonData, error }] =
    useLazyQuery(GET_COMPARISON);

  useEffect(() => {
    const configKeys = [
      "DD_TRACE_SAMPLE_RATE",
      "DD_LOGS_INJECTION",
      "S3_BUCKET",
      "S3_BASE_URL",
      "S3_PUBLIC_BASE_URL",
      "S3_PUBLIC_BUCKET",
      "S3_REGION",
      "LOG_LEVEL",
      "PORT",
      "REDIS_NODES",
      "PRESIGN_ROLE_ARN",
      "ELASTIC_APM_SERVICE_NAME",
      "ELASTIC_APM_SERVER_URL",
      "ELASTIC_APM_TRANSACTION_SAMPLE_RATE",
      "ELASTIC_APM_ENVIRONMENT",
      "ELASTIC_APM_GLOBAL_LABELS",
      "PWREDIS_HOSTS",
      "PWREDIS_ENABLE_CIRCUIT_BREAKER",
      "PWREDIS_KAFKA_ENABLE",
      "PWREDIS_KAFKA_BROKER_LIST",
      "PWREDIS_KAFKA_GROUP_ID",
      "PWREDIS_KAFKA_CLIENT_ID",
      "PWREDIS_SERVICE_NAME",
      "PWMONGO_DB_REDIS_TTL",
      "PWMONGO_DB_IS_REDIS_CLUSTER",
    ];

    const options = configKeys.map((key) => ({
      name: key,
      code: key,
    }));

    setOpts1(options);
  }, []);

  const Opts2 = [
    { name: "DEV", code: "dev" },
    { name: "STAGE", code: "stg" },
    { name: "LT1", code: "lt1" },
    { name: "PROD", code: "pro" },
    { name: "PROD DR", code: "prodr" },
  ];

  const Opts3 = [
    { name: "DEV", code: "dev" },
    { name: "STAGE", code: "stg" },
    { name: "LT1", code: "lt1" },
    { name: "PROD", code: "pro" },
    { name: "PROD DR", code: "prodr" },
  ];

  const handleShowResult = () => {
    if (selectedOpt1 && selectedOpt2 && selectedOpt3) {
      getComparison({
        variables: {
          service: "core-utilities-service",
          environments: [selectedOpt2.name, selectedOpt3.name],
          variables: [selectedOpt1.name],
        },
      });
    } else {
      alert("Please select values from all dropdowns!");
    }
  };

  useEffect(() => {
    if (comparisonData) {
      const newData = comparisonData.compareVariables.map((item) => ({
        variable: item.variable,
        status: item.status,
        envType1: item.values[0]?.environment,
        envType2: item.values[1]?.environment,
        value1: item.values[0]?.value,
        value2: item.values[1]?.value,
      }));
      setData(newData);
      setShowTable(true);
    }
  }, [comparisonData]);

  return (
    <div>
      <div className="p-d-flex p-ai-center p-jc-between p-mx-4">
        <Dropdown
          value={selectedOpt1}
          onChange={(e) => setSelectedOpt1(e.value)}
          options={opts1}
          optionLabel="name"
          editable
          placeholder="Environment Variable Name"
          className="p-mr-2 w-full md:w-14rem"
        />

        <Dropdown
          value={selectedOpt2}
          onChange={(e) => setSelectedOpt2(e.value)}
          options={Opts2}
          optionLabel="name"
          editable
          placeholder="Environments Type1"
          className="p-mr-2 w-full md:w-14rem"
        />

        <Dropdown
          value={selectedOpt3}
          onChange={(e) => setSelectedOpt3(e.value)}
          options={Opts3}
          optionLabel="name"
          editable
          placeholder="Environments Type2"
          className="w-full md:w-14rem"
        />
      </div>
      <div className="p-mt-4">
        <Button
          label="Compare"
          onClick={handleShowResult}
          className="p-mt-2 p-mb-2"
          style={{ marginTop: "20px", marginBottom: "20px" }}
        />
      </div>

      {loading && <p>Loading...</p>}
      {error && <p>Error fetching data: {error.message}</p>}

      {showTable && data.length > 0 && (
        <div className="p-mt-4">
          <DataTable value={data} className="p-datatable-sm">
            <Column field="variable" header="Variable"></Column>
            <Column field="status" header="Status"></Column>
            <Column field="envType1" header="Environment Type 1"></Column>
            <Column field="value1" header="Value Type 1"></Column>
            <Column field="envType2" header="Environment Type 2"></Column>
            <Column field="value2" header="Value Type 2"></Column>
          </DataTable>
        </div>
      )}
    </div>
  );
};

export default DropdownMenu;

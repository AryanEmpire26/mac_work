import { gql } from "@apollo/client";

export const GET_COMPARISON = gql`
  query CompareVariables(
    $service: String!
    $environments: [String!]!
    $variables: [String!]!
  ) {
    compareVariables(
      service: $service
      environments: $environments
      variables: $variables
    ) {
      variable
      status
      values {
        environment
        value
      }
    }
  }
`;

const express = require("express");
const { ApolloServer } = require("@apollo/server");
const { expressMiddleware } = require("@apollo/server/express4");
const bodyParser = require("body-parser");
const cors = require("cors");
const { default: axios } = require("axios");
async function server() {
  const app = express();
  const server = new ApolloServer({
    typeDefs: `
    
    type Todo{
    id:ID!
    title:String!
    completed: Boolean

    }
    type Query{
    gettodos:[Todo]
    }
    
    `,
    resolvers: {
      Query: {
        gettodos: async () => {
          const response = await axios.get(
            "https://jsonplaceholder.typicode.com/todos"
          );
          return response.data;
        },
      },
    },
  });

  await server.start();
  app.use(bodyParser.json());
  app.use(cors());
  app.use("/graphql", expressMiddleware(server));

  app.listen(8000, () => console.log("Server started..."));
}
server();

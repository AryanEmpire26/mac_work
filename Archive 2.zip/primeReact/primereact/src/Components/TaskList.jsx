import React, { useState } from "react";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { Checkbox } from "primereact/checkbox";

function TaskList() {
  const [task, settask] = useState("");
  const [tasks, settasks] = useState([]);

  const addtask = () => {
    if (task) {
      settasks([...tasks, { name: task, completed: false }]);
      settask("");
    }
  };

  const removetask = (taskIndex) => {
    const updatedTasks = tasks.filter((_, index) => index !== taskIndex);
    settasks(updatedTasks);
  };

  const toggleComplete = (taskIndex) => {
    const updatedTasks = tasks.map((t, index) =>
      index === taskIndex ? { ...t, completed: !t.completed } : t
    );
    settasks(updatedTasks);
  };

  return (
    <div
      className="p-d-flex p-ai-center p-jc-center"
      style={{ height: "100vh", flexDirection: "column", textAlign: "center" }}
    >
      <h2>Task Manager</h2>
      <div className="p-field p-grid">
        <div className="p-col-8">
          <InputText
            value={task}
            onChange={(e) => settask(e.target.value)}
            placeholder="Enter new task"
          />
        </div>
        <div className="p-col-4">
          <Button label="Add Task" icon="pi pi-plus" onClick={addtask} />
        </div>
      </div>

      <ul
        className="p-mt-3"
        style={{ listStyle: "none", padding: 0, width: "300px" }}
      >
        {tasks.map((task, index) => (
          <li key={index} className="p-d-flex p-ai-center">
            <Checkbox
              checked={task.completed}
              onChange={() => toggleComplete(index)}
              className="p-mr-2"
            />
            <span
              style={{
                textDecoration: task.completed ? "line-through" : "none",
              }}
            >
              {task.name}
            </span>
            <Button
              icon="pi pi-trash"
              className="p-button-danger p-ml-2 p-mb-2"
              onClick={() => removetask(index)}
            />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TaskList;

// src/casdoorConfig.js

import Sdk from "casdoor-js-sdk";

const casdoorConfig = {
  serverUrl: "http://localhost:8000",
  clientId: "6fd3391a66e4bb91ad37",
  appName: "application_z6dj79_aryan", // Replace with your Casdoor application name
  organizationName: "organization_qqgypk_aryan", // Replace with your Casdoor organization name
  redirectUri: "http://localhost:9000/callback", // Replace with your redirect URI
};

const casdoorSdk = new Sdk(casdoorConfig);

// Method to exchange the authorization code for a token
casdoorSdk.getOAuthToken = async (code) => {
  const response = await fetch(
    `${casdoorConfig.serverUrl}/api/login/oauth2/token`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        code,
        client_id: casdoorConfig.clientId,
        redirect_uri: casdoorConfig.redirectUri,
        grant_type: "authorization_code",
      }),
    }
  );

  if (!response.ok) {
    throw new Error("Failed to exchange code for token");
  }

  const data = await response.json();
  return data.access_token; // Adjust this according to the actual response structure from Casdoor
};

export const getLoginUrl = () => {
  return casdoorSdk.getSigninUrl();
};

export { casdoorSdk };

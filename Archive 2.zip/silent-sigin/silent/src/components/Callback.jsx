// src/components/Callback.jsx

import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { casdoorSdk } from "../casdoorConfig"; // Import your casdoorSdk

const Callback = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const handleCallback = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      console.log("Full URL:", window.location.href); // Log the full URL for debugging
      const code = urlParams.get("code"); // Get the code from the URL

      if (code) {
        try {
          // Exchange the code for a token
          const token = await casdoorSdk.getOAuthToken(code); // This function must be implemented in your casdoorSdk

          if (token) {
            // Store the token in localStorage
            localStorage.setItem("casdoor-token", token);
            navigate("/dashboard");
          } else {
            console.error("No token received from exchange");
            navigate("/login");
          }
        } catch (error) {
          console.error("Error exchanging code for token:", error);
          navigate("/login");
        }
      } else {
        console.error("No code received");
        navigate("/login");
      }
    };

    handleCallback();
  }, [navigate]);

  return <div>Processing callback...</div>;
};

export default Callback;

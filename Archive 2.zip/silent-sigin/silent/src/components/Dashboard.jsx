// src/components/Dashboard.jsx

import React from "react";

const Dashboard = () => {
  return <div>Welcome to the Dashboard!</div>;
};

export default Dashboard;

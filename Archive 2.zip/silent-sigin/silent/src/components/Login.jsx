// src/components/Login.jsx

import React from "react";
import { getLoginUrl } from "../casdoorConfig";

const Login = () => {
  const handleLogin = () => {
    // Redirect to Casdoor's login page
    window.location.href = getLoginUrl();
  };

  return (
    <div>
      <button onClick={handleLogin}>Login with Casdoor</button>
    </div>
  );
};

export default Login;

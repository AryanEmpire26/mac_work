// src/components/SilentLogin.jsx

import React, { useEffect } from "react";
import { casdoorSdk } from "../casdoorConfig"; // Correct import
import { useNavigate } from "react-router-dom";

const SilentLogin = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const silentLogin = async () => {
      try {
        const token = localStorage.getItem("casdoor-token");
        if (token) {
          const userInfo = await casdoorSdk.validateToken(token);
          if (userInfo) {
            console.log("Logged in as:", userInfo);
            navigate("/dashboard");
          } else {
            localStorage.removeItem("casdoor-token");
            navigate("/login");
          }
        } else {
          navigate("/login");
        }
      } catch (error) {
        console.error("Silent login error:", error);
        navigate("/login");
      }
    };

    silentLogin();
  }, [navigate]);

  return <div>Loading...</div>;
};

export default SilentLogin;
